
/*browser:true*/
/*global define*/
define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'suntech_webatm',
                component: 'SunTech_WebATM/js/view/payment/method-renderer/suntech_webatm'
            }
        );
        /** Add view logic here if needed */
        return Component.extend({});
    }
);
