<?php

namespace SunTech\WebATM\Gateway\Validator;

use Magento\Framework\Exception\NotFoundException;
use Magento\Payment\Gateway\ConfigInterface;
use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Validator\ResultInterface;
use Magento\Payment\Gateway\Validator\ResultInterfaceFactory;

/**
 * Class CountryValidator
 * @package Magento\Payment\Gateway\Validator
 * @api
 */
class ResponseCodeValidator extends AbstractValidator
{
    /**
     * @var \Magento\Payment\Gateway\ConfigInterface
     */
    private $config;

    /**
     * @param ResultInterfaceFactory $resultFactory
     * @param \Magento\Payment\Gateway\ConfigInterface $config
     */
    public function __construct(
        ResultInterfaceFactory $resultFactory,
        ConfigInterface $config
    ) {
        $this->config = $config;
        parent::__construct($resultFactory);
    }

    /**
     * @param array $validationSubject
     * @return ResultInterface
     * @throws NotFoundException
     * @throws \Exception
     */
    public function validate(array $validationSubject)
    {
        $isValid = true;
        $storeId = $validationSubject['storeId'];

        if ((int)$this->config->getValue('cargo_flag', $storeId) === 1) {
            if (!in_array($validationSubject['select_cargo_flag'], [0, 1])) {
                $isValid =  false;
            }
        }

        $availableInstallments = explode(
            ',',
            $this->config->getValue('installments', $storeId)
        );

        if (!in_array($validationSubject['select_installments'], $availableInstallments)) {
            $isValid =  false;
        }

        return $this->createResult($isValid);
    }
}
