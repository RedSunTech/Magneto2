<?php
namespace SunTech\WebATM\Controller\Payment;

use Magento\Backend\App\Action\Context;

class Response extends Base
{
    public function __construct(Context $context)
    {
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_order = $this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($_REQUEST["Td"]);

        try {
            if (!$this->_order) throw new \Exception(__("The order doesn't exist."));

            //組態參數
            $store_pwd = $this->_getConfigValue('store_pwd');
            $order_paid_status = $this->_getConfigValue('order_paid_status');

            //回傳參數
            $request = $_REQUEST;
            $web = $request['web'];
            $buysafeno = $request['buysafeno'];
            $note1 = $request['note1'];
            $chkValue = $request['ChkValue'];
            $SendType = isset($request["SendType"]) ? $request["SendType"] : 1;
            $MN = isset($request['MN']) ? $request['MN'] : '';
            $errcode = isset($request['errcode']) ? $request['errcode'] : '';
            $errmsg = isset($request['errmsg']) ? urldecode($request['errmsg']) : '';
            $CargoNo = isset($request['CargoNo']) ? $request['CargoNo'] : '';
            $StoreName = isset($request['StoreName']) ? urldecode($request['StoreName']) : '';
            $StoreID = isset($request['StoreID']) ? $request['StoreID'] : '';
            $StoreType = isset($request['StoreType']) ? $request['StoreType'] : '';
            $StoreMsg = isset($request['StoreMsg']) ? urldecode($request['StoreMsg']) : '';

            if ($note1 == 'webatm') {
                if ($MN AND $MN != intval(round($this->_order["grand_total"]))) throw new \Exception(__("The grand total mismatch."));
                switch ($chkValue) {

                    //繳費成功
                    case $this->getCheckValue(array($web, $store_pwd, $buysafeno, $MN, $errcode, $CargoNo)):
                        $log_exsist = ($this->_order->getStatus() == $order_paid_status) ? true : false;
                        if ($log_exsist) break;
                        if ($errcode == '00') {
                            $comment = sprintf(__('SunTech Paid'), $buysafeno);
                            $this->_addCustomerComment($comment, $order_paid_status, true, true, false);

                            if ($CargoNo) {
                                $cargo_comment = sprintf(__('CVS Info'),
                                    $CargoNo, $StoreName, $StoreID);
                                $this->_addCustomerComment($cargo_comment, false, false, true, false);
                            }
                        } else {
                            $comment = sprintf(__('Failed Payments'), $buysafeno, $errmsg);
                            $this->messageManager->addErrorMessage($comment);
                            if ($this->_order->getStatus() == 'canceled') break;
                            $this->_addCustomerComment($comment, 'canceled');
                        }
                        break;

                    case strtoupper(sha1($web . $store_pwd . $buysafeno . $StoreType)):
                        switch ($StoreType) {
                            case '1010':
                                $status = 'complete';
                                break;
                            default:
                                $status = false;
                        }
                        $this->_addCustomerComment($StoreMsg, $status);
                        break;
                    default:
                        throw new \Exception('chkValue mismatch (chkValue:' . $chkValue . ', web:' . $web . ')');
                }
                if ($SendType == 1) {
                    echo '0000';
                    exit;
                }
            }
            else {
                throw new \Exception('$note1 mismatch ('  . $note1 . ')');
            }
        } catch (\Exception $e) {
            $this->_log($e->getMessage());
            $this->messageManager->addErrorMessage(__('Something went wrong, please try again.'));
        }
        $this->_redirect('checkout/onepage/success');
    }
}
