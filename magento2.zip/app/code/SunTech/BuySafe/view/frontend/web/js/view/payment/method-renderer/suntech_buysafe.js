
/*browser:true*/
/*global define*/
define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/action/place-order',
        'mage/url'
    ],
    function ($, Component, placeOrderAction, url) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'SunTech_BuySafe/payment/form',
                selectInstallments: '',
                selectCargoFlag: 0
            },

            initObservable: function () {
                this._super()
                    .observe([
                        'selectInstallments',
                        'selectCargoFlag'
                    ]);
                return this;
            },

            getCode: function() {
                return 'suntech_buysafe';
            },

            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'select_installments': this.selectInstallments(),
                        'select_cargo_flag': this.selectCargoFlag()
                    }
                };
            },

            getAvailableInstallments: function () {
                return _.map(window.checkoutConfig.payment.suntech_buysafe.availableInstallments, function(value, key) {
                    return {
                        'value': key,
                        'select_installments': value
                    }
                });
            },
            isActiveCargo: function () {
                return window.checkoutConfig.payment.suntech_buysafe.cargoFlag;
            },
            placeOrder: function (data, event) {
                var self = this;
                if (event) {
                    event.preventDefault();
                }
                self.isPlaceOrderActionAllowed(false);
                self.getPlaceOrderDeferredObject()
                    .fail(
                        function () {
                            self.isPlaceOrderActionAllowed(true);
                        }
                    )
                    .done(
                        function () {
                            $.mage.redirect(url.build('suntech_buysafe/payment/redirect'));
                            return false;
                        }
                    );
                return false
            },

            getPlaceOrderDeferredObject: function () {
                return $.when(
                    placeOrderAction(this.getData(), this.messageContainer)
                );
            }
        });
    }
);