<?php

namespace SunTech\BuySafe\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Payment\Helper\Data as PaymentHelper;
use SunTech\BuySafe\Model\Config\Source\Installments;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'suntech_buysafe';
    private $method;

    public function __construct(PaymentHelper $paymentHelper)
    {
        $this->method = $paymentHelper->getMethodInstance(self::CODE);
    }

    /**
     * Get Available Installments from config
     *
     * @return array
     */
    private function getAvailableInstallments()
    {
        $installments = new Installments();
        $data = [];
        $config_installments = explode(',', $this->method->getConfigData('installments'));
        foreach ($installments->toOptionArray() as $installment) {
            if ($installment['value'] == 0 || in_array($installment['value'], $config_installments)) {
                $data[$installment['value']] = $installment['label'];
            }
        }

        return $data;
    }

    /**
     * Get cargo_flg from config
     *
     * @return boolean
     */
    private function getCargoFlag()
    {
        return ($this->method->getConfigData('cargo_flag'))?true:false;
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        return [
            'payment' => [
                self::CODE => [
                    'availableInstallments' => $this->getAvailableInstallments(),
                    'cargoFlag' => $this->getCargoFlag()
                ]
            ]
        ];
    }
}
