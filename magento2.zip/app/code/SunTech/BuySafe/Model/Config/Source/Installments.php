<?php

namespace SunTech\BuySafe\Model\Config\Source;

class Installments implements \Magento\Framework\Option\ArrayInterface
{
    protected $_options;
    private $_installments;

    public function __construct()
    {
        $this->_installments = array(
            0 => __('Lump Sum'),
            3 => __('3 installments'),
            6 => __('6 installments'),
            12 => __('12 installments'),
            18 => __('18 installments'),
            24 => __('24 installments')
        );
    }

    public function toOptionArray($isMultiselect = false)
    {
        if (!$this->_options) {
            foreach ($this->_installments as $key => $installment) {
                $this->_options[] = array('value' => $key, 'label' => $installment);
            }
        }

        $options = $this->_options;
        if (!$isMultiselect) {
            array_unshift($options, array('value' => 0, 'label' => __('Lump Sum')));
        }

        return $options;
    }
}
