<?php

namespace SunTech\BuySafe\Observer;

use Magento\Framework\Event\Observer;
use Magento\Payment\Observer\AbstractDataAssignObserver;

class DataAssignObserver extends AbstractDataAssignObserver
{
    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $method = $this->readMethodArgument($observer);
        $data = $this->readDataArgument($observer);

        $additional_data = $data->getData('additional_data');
        $select_installments = (int)$additional_data['select_installments'];
        $select_cargo_flag = (int)$additional_data['select_cargo_flag'];
        $paymentInfo = $method->getInfoInstance();

        if (is_integer($select_installments) && $select_installments > 0) {
            $paymentInfo->setAdditionalInformation('select_installments', $select_installments);
        }

        if (is_integer($select_cargo_flag) && $select_cargo_flag == 1) {
            $paymentInfo->setAdditionalInformation('select_cargo_flag', $select_cargo_flag);
        }
    }
}
