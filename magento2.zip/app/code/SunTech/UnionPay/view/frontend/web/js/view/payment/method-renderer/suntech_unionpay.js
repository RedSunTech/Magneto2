
/*browser:true*/
/*global define*/
define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/action/place-order',
        'mage/url'
    ],
    function ($, Component, placeOrderAction, url) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'SunTech_UnionPay/payment/form'
            },

            getCode: function() {
                return 'suntech_unionpay';
            },

            getData: function() {
                return {
                    'method': this.item.method
                };
            },

            placeOrder: function (data, event) {
                var self = this;
                if (event) {
                    event.preventDefault();
                }
                self.isPlaceOrderActionAllowed(false);
                self.getPlaceOrderDeferredObject()
                    .fail(
                        function () {
                            self.isPlaceOrderActionAllowed(true);
                        }
                    )
                    .done(
                        function () {
                            $.mage.redirect(url.build('suntech_unionpay/payment/redirect'));
                            return false;
                        }
                    );
                return false
            },

            getPlaceOrderDeferredObject: function () {
                return $.when(
                    placeOrderAction(this.getData(), this.messageContainer)
                );
            }
        });
    }
);