<?php

namespace SunTech\PayCode\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Payment\Helper\Data as PaymentHelper;
use SunTech\PayCode\Model\Config\Source\Installments;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'suntech_paycode';
    private $method;

    public function __construct(PaymentHelper $paymentHelper)
    {
        $this->method = $paymentHelper->getMethodInstance(self::CODE);
    }

    /**
     * Get cargo_flg from config
     *
     * @return boolean
     */
    private function getCargoFlag()
    {
        return ($this->method->getConfigData('cargo_flag'))?true:false;
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        return [
            'payment' => [
                self::CODE => [
                    'cargoFlag' => $this->getCargoFlag()
                ]
            ]
        ];
    }
}
