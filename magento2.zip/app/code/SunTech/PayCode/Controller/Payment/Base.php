<?php

namespace SunTech\PayCode\Controller\Payment;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Zend\Log\Logger;
use Zend\Log\Writer\Stream;

Abstract class Base extends Action
{
    protected $resultFactory;
    protected $_checkoutSession;
    protected $_scopeConfig;
    protected $_order;
    protected $logger;

    public function __construct(Context $context)
    {
        parent::__construct($context);
        $this->_scopeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
        $writer = new Stream(BP . '/var/log/suntech.log');
        $this->logger = new Logger();
        $this->logger->addWriter($writer);
    }

    protected function _getConfigValue($key)
    {
        $path = 'payment/' . $this->_order->getPayment()->getMethod() . '/' . $key;
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $this->_order->getStoreId());
    }

    /**
     * @param string $msg
     */
    protected function _log($msg)
    {
        $prefix = 'Payment: ' . $this->_order->getPayment()->getMethod() . ', Error Messasg: ';
        $this->logger->info($prefix . $msg);
    }

    /**
     * @param array $values
     * @return string
     */
    protected function getCheckValue($values)
    {
        return strtoupper(sha1(implode('', $values)));
    }

    /**
     * Add Order Backend Comment
     *
     * @param string $comment
     * @param bool $status
     */
    protected function _addAdminComment($comment, $status = false)
    {
        $this->_order->addStatusHistoryComment($comment, $status);
        $this->_order->save();
    }

    /**
     * Add Order Frontend Comment
     *
     * @param string $comment
     * @param bool $status
     * @param bool $notify
     * @param bool $front
     * @param bool $send_email
     */
    protected function _addCustomerComment($comment, $status = false, $notify = true, $front = true, $send_email = true)
    {
        $this->_order->addStatusHistoryComment($comment, $status)
            ->setIsCustomerNotified($notify)
            ->setIsVisibleOnFront($front);
        $this->_order->save();

        if ($send_email) {
            $this->_order->setSendEmail(true, $comment);
        }
    }
}
