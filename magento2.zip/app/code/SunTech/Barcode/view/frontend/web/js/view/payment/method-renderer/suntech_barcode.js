
/*browser:true*/
/*global define*/
define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/action/place-order',
        'mage/url'
    ],
    function ($, Component, placeOrderAction, url) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'SunTech_Barcode/payment/form',
                selectCargoFlag: 0
            },

            initObservable: function () {
                this._super()
                    .observe([
                        'selectCargoFlag'
                    ]);
                return this;
            },

            getCode: function() {
                return 'suntech_barcode';
            },

            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'select_cargo_flag': this.selectCargoFlag()
                    }
                };
            },

            isActiveCargo: function () {
                return window.checkoutConfig.payment.suntech_barcode.cargoFlag;
            },

            placeOrder: function (data, event) {
                var self = this;
                if (event) {
                    event.preventDefault();
                }
                self.isPlaceOrderActionAllowed(false);
                self.getPlaceOrderDeferredObject()
                    .fail(
                        function () {
                            self.isPlaceOrderActionAllowed(true);
                        }
                    )
                    .done(
                        function () {
                            $.mage.redirect(url.build('suntech_barcode/payment/redirect'));
                            return false;
                        }
                    );
                return false
            },

            getPlaceOrderDeferredObject: function () {
                return $.when(
                    placeOrderAction(this.getData(), this.messageContainer)
                );
            }
        });
    }
);