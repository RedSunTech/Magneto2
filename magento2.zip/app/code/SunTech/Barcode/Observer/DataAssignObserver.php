<?php

namespace SunTech\Barcode\Observer;

use Magento\Framework\Event\Observer;
use Magento\Payment\Observer\AbstractDataAssignObserver;

class DataAssignObserver extends AbstractDataAssignObserver
{
    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $method = $this->readMethodArgument($observer);
        $data = $this->readDataArgument($observer);

        $additional_data = $data->getData('additional_data');
        $select_cargo_flag = (int)$additional_data['select_cargo_flag'];
        $paymentInfo = $method->getInfoInstance();

        if (is_integer($select_cargo_flag) && $select_cargo_flag == 1) {
            $paymentInfo->setAdditionalInformation('select_cargo_flag', $select_cargo_flag);
        }

        $due_date = (int)$paymentInfo->getMethodInstance()->getConfigData('due_date');
        if (is_integer($due_date) && $due_date > 0) {
            $paymentInfo->setAdditionalInformation('due_date', Date('Y-m-d', strtotime("+" . $due_date . " days")));
        }
    }
}
