
/*browser:true*/
/*global define*/
define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/action/place-order',
        'mage/url'
    ],
    function ($, Component, placeOrderAction, url) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'SunTech_SunShip/payment/form'
            },

            getCode: function() {
                return 'suntech_sunship';
            },

            getData: function() {
                return {
                    'method': this.item.method
                };
            },

            placeOrder: function (data, event) {
                var self = this;
                if (event) {
                    event.preventDefault();
                }
                self.isPlaceOrderActionAllowed(false);
                self.getPlaceOrderDeferredObject()
                    .fail(
                        function () {
                            self.isPlaceOrderActionAllowed(true);
                        }
                    )
                    .done(
                        function () {
                            $.mage.redirect(url.build('suntech_sunship/payment/redirect'));
                            return false;
                        }
                    );
                return false
            },

            getPlaceOrderDeferredObject: function () {
                return $.when(
                    placeOrderAction(this.getData(), this.messageContainer)
                );
            },

            isAvalible: function() {
                var grand_total = Number(window.checkoutConfig.payment.suntech_sunship.grand_total);
                if (grand_total < 50) {
                    return false;    
                }
                return true;
            }
        });
    }
);