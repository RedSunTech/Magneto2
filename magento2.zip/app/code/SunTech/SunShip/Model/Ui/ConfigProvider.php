<?php

namespace SunTech\SunShip\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Payment\Helper\Data as PaymentHelper;
use SunTech\SunShip\Model\Config\Source\Installments;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'suntech_sunship';
    private $method;

    public function __construct(PaymentHelper $paymentHelper)
    {
        $this->method = $paymentHelper->getMethodInstance(self::CODE);
    }
    

    /**
    */
    public function getGrandTotal()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart'); 
        return $cart->getQuote()->getGrandTotal();
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {

        return [
            'payment' => [
                self::CODE => [
                            'grand_total' => $this->getGrandTotal()
                ]
            ]
        ];
    }
}
