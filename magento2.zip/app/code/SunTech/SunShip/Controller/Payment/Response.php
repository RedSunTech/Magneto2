<?php
namespace SunTech\SunShip\Controller\Payment;

use Magento\Backend\App\Action\Context;

class Response extends Base
{
    public function __construct(Context $context)
    {
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_order = $this->_objectManager->get('Magento\Sales\Model\Order')->loadByIncrementId($_REQUEST["Td"]);

        try {
            if (!$this->_order) throw new \Exception(__("The order doesn't exist."));

            //組態參數
            $store_pwd = $this->_getConfigValue('store_pwd');
            $order_init_status = $this->_getConfigValue('order_init_status');

            //回傳參數
            $request = $_REQUEST;
            $web = $request['web'];
            $buysafeno = $request['buysafeno'];
            $note1 = $request['note1'];
            $chkValue = $request['ChkValue'];
            $SendType = isset($request["SendType"]) ? $request["SendType"] : 1;
            $MN = isset($request['MN']) ? $request['MN'] : '';
            $errcode = isset($request['errcode']) ? $request['errcode'] : '';
            $errmsg = isset($request['errmsg']) ? urldecode($request['errmsg']) : '';
            $CargoNo = isset($request['CargoNo']) ? $request['CargoNo'] : '';
            $StoreName = isset($request['StoreName']) ? urldecode($request['StoreName']) : '';
            $StoreID = isset($request['StoreID']) ? $request['StoreID'] : '';
            $StoreType = isset($request['StoreType']) ? $request['StoreType'] : '';
            $StoreMsg = isset($request['StoreMsg']) ? urldecode($request['StoreMsg']) : '';

            //訂單參數
            $additional_info = $this->_order->getPayment()->getData('additional_information');

            if ($note1 == 'sunship') {
                if ($MN AND $MN != intval(round($this->_order["grand_total"]))) throw new \Exception(__("The grand total mismatch."));
                switch ($chkValue) {

                    //成立訂單
                    case $this->getCheckValue(array($web, $store_pwd, $buysafeno, $MN, $CargoNo)):
                        $log_exsist = ($this->_order->getStatus() == $order_init_status) ? true : false;
                        if ($log_exsist) break;
                        $comment = sprintf(__('CVS Info'), $CargoNo, $StoreName, $StoreID);
                        $this->_addCustomerComment($comment, $order_init_status, true, true, false);
                        break;

                    case strtoupper(sha1($web . $store_pwd . $buysafeno . $StoreType)):
                        switch ($StoreType) {
                            case '1010':
                                $status = 'complete';
                                break;
                            default:
                                $status = false;
                        }
                        $this->_addCustomerComment($StoreMsg, $status);
                        break;

                    //繳費成功
                    case $this->getCheckValue(array($web, $store_pwd, $buysafeno, $MN, $errcode)):
                        $log_exsist = ($this->_order->getStatus() == 'complete') ? true : false;
                        if ($log_exsist) break;
                        if ($errcode == '00') {
                            $comment = sprintf(__('SunTech Paid'), $buysafeno);
                            $this->_addCustomerComment($comment, 'complete', true, true, false);
                        } else {
                            $comment = sprintf(__('Failed Payments'), $buysafeno, $errmsg);
                            $this->_addCustomerComment($comment, 'canceled');
                        }
                        break;
                    default:
                        throw new \Exception('chkValue mismatch (chkValue:' . $chkValue . ', web:' . $web . ')');
                }
                if ($SendType == 1) {
                    echo '0000';
                    exit;
                }
            }
            else {
                throw new \Exception('$note1 mismatch ('  . $note1 . ')');
            }
        } catch (\Exception $e) {
            $this->_log($e->getMessage());
            $this->messageManager->addErrorMessage(__('Something went wrong, please try again.'));
        }
        $this->_redirect('checkout/onepage/success');
    }
}
