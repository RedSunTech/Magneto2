<?php
namespace SunTech\SunShip\Controller\Payment;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Context;

class Redirect extends Base
{
    public function __construct(Context $context, Session $checkoutSession)
    {
        parent::__construct($context);
        $this->_order = $checkoutSession->getLastRealOrder();
    }

    public function execute()
    {
        try {
            if (!$this->_order) throw new \Exception(__("The order doesn't exist."));

            //取得參數
            $test_mode = $this->_getConfigValue('test_mode');
            $store_id = $this->_getConfigValue('store_id');
            $store_pwd = $this->_getConfigValue('store_pwd');
            $order_init_status = $this->_getConfigValue('order_init_status');

            //客戶資料
            $customer_phone = $this->_order->getBillingAddress()->getTelephone();
            $customer_name = $this->_order->getBillingAddress()->getName();

            //判斷是否測試模式
            $url = ($test_mode == '0' ? 'https://www.esafe.com.tw/Service/Etopm.aspx' : 'https://test.esafe.com.tw/Service/Etopm.aspx');

            //訂單資料
            $total_pay = intval(round($this->_order["grand_total"]));

            //送出付款資訊
            $shtml = '<div style="text-align:center;" ><form name="myform" id="myform" method="post" action="' . $url . '">';
            $shtml .="<input type='hidden' name='web' value='" . $store_id . "' />"; //商店代號
            $shtml .="<input type='hidden' name='MN' value='" . $total_pay . "' />"; //交易金額
            $shtml .="<input type='hidden' name='Td' value='" . $this->_order["increment_id"] . "' />"; //商家訂單編號
            $shtml .="<input type='hidden' name='sna' value='" . $customer_name . "' />"; //消費者姓名
            if (preg_match("/^[0-9]+$/", $customer_phone) == 1) {
                $shtml .="<input type='hidden' name='sdt' value='" . $customer_phone . "' />"; //消費者電話
            }
            $shtml .="<input type='hidden' name='email' value='" . $this->_order["customer_email"] . "' />"; //消費者 Email
            $shtml .="<input type='hidden' name='note1' value='sunship' />";
            $shtml .="<input type='hidden' name='ChkValue' value='" . $this->getCheckValue(array($store_id, $store_pwd, $total_pay)) . "' />";
            $shtml .= '<script type="text/javascript">document.myform.submit();</script>';
            $shtml .= '</form></div>';

            $comment = __('Payment Type') . ' : ' . __('SunShip');
            $this->_addCustomerComment($comment, 'pending', true, true, false);

            echo $shtml;
            exit();
        } catch (\Exception $e) {
            $this->_log($e->getMessage());
            $this->messageManager->addErrorMessage(__('Something went wrong, please try again.'));
        }
        $this->_redirect('checkout/onepage/success');
    }
}